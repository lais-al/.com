import os
import time
from google import genai

client = genai.Client(
    api_key=os.environ.get("GEMINI_API_KEY"),
)

tools = [
    {
        'type': 'google_search',
    },
]

interaction = client.interactions.create(
    agent='antigravity-preview-09-2026',
    input="""INSERT_INPUT_HERE""",
    background=True,
    tools=tools,
    environment='108b9ab42fad3a36f159cb7a53f04a69',
)

print(f"Research started: {interaction.id}")

while True:
    interaction = client.interactions.get(interaction.id)
    if interaction.status == "completed":
        print(interaction.output_text)
        break
    elif interaction.status == "failed":
        print(f"Research failed: {interaction.error}")
        break
    time.sleep(10)


